import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListarComponent } from './listar/listar.component';
import { IncluirComponent } from './incluir/incluir.component';
import { EditarComponent } from './editar/editar.component';

const routes: Routes = [
  {path:'listar', component:ListarComponent},
  {path:'incluir', component:IncluirComponent},
  {path:'editar/:id', component:EditarComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
