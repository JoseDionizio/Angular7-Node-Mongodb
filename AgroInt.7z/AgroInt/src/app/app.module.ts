import { BrowserModule } from '@angular/platform-browser';
import { NgModule,LOCALE_ID } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedMaterialModule } from './core/shared-material.module';
import { MAT_DATE_LOCALE, MatPaginatorIntl, DateAdapter } from '@angular/material';
import { ListarComponent } from './listar/listar.component';
import { IncluirComponent } from './incluir/incluir.component';
import { DataService } from './core/service/data.service';

import ptBr from '@angular/common/locales/pt';
import { registerLocaleData } from '@angular/common';
import { EditarComponent } from './editar/editar.component';

registerLocaleData(ptBr);

@NgModule({
  declarations: [
    AppComponent,
    ListarComponent,
    IncluirComponent,
    EditarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedMaterialModule,
    HttpClientModule   
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'pt' },
    { provide: MAT_DATE_LOCALE, useValue: 'pt' },
    DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
