export class Hectare {
    public Area: string;
    public Defensivo: string;
    public Qt_Aplicado: string;

    constructor(documentos: Array<any[]>){
        this.Area = documentos['Area'];
        this.Defensivo = documentos['Defensivo'];
        this.Qt_Aplicado = documentos['Qt_Aplicado'];
    }
}
