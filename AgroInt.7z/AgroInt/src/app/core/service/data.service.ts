import { Injectable } from '@angular/core';
import { Hectare } from '../models/hectare';
import { HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import { Observable, of  } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError, retry } from 'rxjs/operators';
import {URL} from '../URL'

@Injectable({providedIn: 'root'})
export class DataService {
 

  constructor(private _http: HttpClient) { }

   

  SalvarHectare(hectare:Hectare){
    return this._http.post<Hectare>(`${URL}`, hectare).pipe(
      map(res => { return res }));
  }

  UpdateHectare(hectare:Hectare, id:string){
    return this._http.put<Hectare>(`${URL}${id}`, hectare).pipe(
      map(res => { return res }));
  }

  GetHectareID(id : string): Observable<Hectare[]>{
    return this._http.get<Hectare[]>(`${URL}${id}`);
     
  }
  GetHectare(): Observable<Hectare[]>{
    return this._http.get<Hectare[]>(`${URL}`);
     
  }
  DeleteH(id : string): Observable<{}>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'      
      })
    };
    return this._http.delete(`${URL}${id}`,httpOptions).pipe(
      map(res => { return res }));

  }
  
  
}
