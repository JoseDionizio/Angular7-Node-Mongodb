import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../core/service/data.service';
import { Hectare } from '../core/models/hectare';


@Component({
  selector: 'app-editar',
  templateUrl: './editar.component.html',
  styleUrls: ['./editar.component.css']
})
export class EditarComponent implements OnInit {
  classe: string = 'form-control has-error';
  docForm: FormGroup;
  id:string;
  area:string;
  def:string;
  quanti:string;
  dados: any[] = [];
  constructor(private rout : ActivatedRoute,
    private _formbuilder: FormBuilder,
    private _hectareService : DataService,
    private _rota :Router )
    {
      this.id = this.rout.snapshot.params['id'];
      

     }

  ngOnInit() {
    this.docForm = this._formbuilder.group({
      Area: [null],
      Defensivo: [null],
      Qt_Aplicado: [null]      
    });


    this._hectareService.GetHectareID(this.id).subscribe(x=>{
      this.dados.pop();
      this.dados.push(x);     
      this.area = this.dados['0']['0'].Area;
      this.docForm.setValue({
        Area:this.area,
        Defensivo:this.dados['0']['0'].Defensivo,
        Qt_Aplicado:this.dados['0']['0'].Qt_Aplicado
      })
      
    })

   
    console.log( this.area)
  }

  Salvar(){
    let hectare= new Hectare(this.docForm.value)
    this._hectareService.UpdateHectare(hectare,this.id).subscribe(x=>{
      console.log(x);
    });
    this._rota.navigate(['listar']);

  }

}
