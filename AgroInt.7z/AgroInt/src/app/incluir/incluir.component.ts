import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators} from '@angular/forms';
import { Hectare } from '../core/models/hectare';
import {DataService} from '../core/service/data.service';

@Component({
  selector: 'app-incluir',
  templateUrl: './incluir.component.html',
  styleUrls: ['./incluir.component.css']
})
export class IncluirComponent implements OnInit {
  docForm: FormGroup;
  classe: string = 'form-control has-error';
  constructor(
    private _formbuilder: FormBuilder,
    private _hectareService : DataService
    ) { }

  ngOnInit() {
    this.docForm = this._formbuilder.group({
      Area: [null],
      Defensivo: [null],
      Qt_Aplicado: [null]      
    });
    
  }
  Salvar(){
    let hectare= new Hectare(this.docForm.value)
     this._hectareService.SalvarHectare(hectare).subscribe(data=>{
      console.log(data);
    }, (err) => {
      console.log(err);
    });
    
    
  }

}
