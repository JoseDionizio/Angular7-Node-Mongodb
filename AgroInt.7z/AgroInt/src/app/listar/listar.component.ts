import { Component, OnInit } from '@angular/core';
import {DataService} from '../core/service/data.service';
import { Hectare } from '../core/models/hectare';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css']
})
export class ListarComponent implements OnInit {
  colmns: any[] = [];
  dados: Observable<Hectare[]>;

  constructor(
    private _hectareService : DataService,
    private _rota :Router) { }

  ngOnInit() {
    this.colmns = ["Editar", "Excluir", "Area", "Defensivo","Quantidade"]

    this.dados = this._hectareService.GetHectare();
    
   
  }

  Editar(codigo:string){
    this._rota.navigate(['editar',codigo]);
  }
  Excluir(codigo:string){
   this._hectareService.DeleteH(codigo).subscribe(dt=>{
     console.log(dt)
   }); 
  this._rota.navigate(['incluir']);
  }
  


  
  

}
